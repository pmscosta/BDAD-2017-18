PRAGMA foreign_keys=ON;

drop TRIGGER insertSharing;
