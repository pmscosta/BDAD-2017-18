PRAGMA foreign_keys=ON;

SELECT * FROM SHARING WHERE book = 1;

INSERT INTO Message(date, body, receiver, sender, context) VALUES('2018-08-20 20:23:03','[Share][Complete]', 2, 5, 1);

SELECT * FROM SHARING WHERE book = 1;